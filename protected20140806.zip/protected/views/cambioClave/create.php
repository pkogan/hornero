<?php
/* @var $this CambioClaveController */
/* @var $model CambioClave */

$this->breadcrumbs=array(
	'Cambio Claves'=>array('index'),
	'Create',
);


?>

<h1>Cambio Clave</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>