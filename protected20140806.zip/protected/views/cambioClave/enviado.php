<?php
/* @var $this CambioClaveController */
/* @var $model CambioClave */




?>

<h2>Se ha enviado un mail a # <?php echo $model->email; ?></h2>

<p>Siga las instrucciones del mail para actualizar su clave </p>
