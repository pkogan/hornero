<?php
$token='';
$problema=1;
$urlsolicitud="http://10.42.0.1/yii/hornero/index.php?r=juego/solicitud&token=$token&problema=$problema";
echo $urlsolicitud;
$handle = fopen ($urlsolicitud,'r');
$json= fgets($handle);
$solicitud=json_decode($json);

print_r($solicitud);

$tokenSolicitud=$solicitud->token;
$parametros=  explode(',', $solicitud->parametrosEntrada);
//sleep(10);
$respuesta=$parametros[0]+$parametros[1];

$urlrespuesta="http://10.42.0.1/yii/hornero/index.php?r=juego/respuesta&tokenSolicitud=$tokenSolicitud&solucion=$respuesta";
echo $urlrespuesta;
$handle = fopen ($urlrespuesta,'r');
$json= fgets($handle);
$respuesta=json_decode($json);

print_r($respuesta);

?>
