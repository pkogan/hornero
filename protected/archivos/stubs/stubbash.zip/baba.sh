#!/bin/bash
UNO=$1
DOS=$2
expr $UNO + $DOS 
